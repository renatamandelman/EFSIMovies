import React from 'react'

const card = ({ pelicula }) =>  {
  return (
    <div className="card">
      <img src="" class="card-img-top" alt="..."></img>
      <div className="card-body">
        <h4 className="card-title">Title</h4>
        <p className="card-text">descripcion</p>
      </div>
    </div>
  
  )
};

export default card