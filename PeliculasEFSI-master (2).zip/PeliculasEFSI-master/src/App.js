import './App.css';
import React from 'react';
import Navbar from './components/Navbar';
import Card from './components/Cards/card';
import Footer from './components/footer';


function App(){
 
   return ( 
   <>
<Navbar/>
<Card/>
<Footer/>
</>
 );
}

export default App;
